def display(item):
	if isinstance(item,str):
		print(":"+item)
	else:
		print(item)
