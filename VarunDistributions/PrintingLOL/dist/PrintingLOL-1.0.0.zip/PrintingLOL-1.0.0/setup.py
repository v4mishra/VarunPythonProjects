from distutils.core import setup
setup(
	name = 'PrintingLOL',
	version = '1.0.0',
	py_modules = ['printLol','display'],
	author = 'varun',
	author_email = 'hfpython@headfirstlabs.com',
	url = 'http://www.headfirstlabs.com',
	description = 'A simple printer of nested lists',
	)